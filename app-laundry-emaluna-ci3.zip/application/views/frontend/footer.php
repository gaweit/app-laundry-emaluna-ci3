<section class="footer">
  <p class="text-center text-white copyright">Sistem Manajemen Emaluna Laundry 2022</p>
</section>